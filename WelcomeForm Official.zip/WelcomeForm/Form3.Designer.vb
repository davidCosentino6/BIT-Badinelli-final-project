﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm6ManagerLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl6ManagerUsername = New System.Windows.Forms.Label()
        Me.lbl6ManagerPassword = New System.Windows.Forms.Label()
        Me.txt6ManagerUInput = New System.Windows.Forms.TextBox()
        Me.txt6ManagerPInput = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lbl6ManagerUsername
        '
        Me.lbl6ManagerUsername.AutoSize = True
        Me.lbl6ManagerUsername.Location = New System.Drawing.Point(60, 63)
        Me.lbl6ManagerUsername.Name = "lbl6ManagerUsername"
        Me.lbl6ManagerUsername.Size = New System.Drawing.Size(58, 13)
        Me.lbl6ManagerUsername.TabIndex = 1
        Me.lbl6ManagerUsername.Text = "Username:"
        '
        'lbl6ManagerPassword
        '
        Me.lbl6ManagerPassword.AutoSize = True
        Me.lbl6ManagerPassword.Location = New System.Drawing.Point(62, 123)
        Me.lbl6ManagerPassword.Name = "lbl6ManagerPassword"
        Me.lbl6ManagerPassword.Size = New System.Drawing.Size(56, 13)
        Me.lbl6ManagerPassword.TabIndex = 2
        Me.lbl6ManagerPassword.Text = "Password:"
        '
        'txt6ManagerUInput
        '
        Me.txt6ManagerUInput.Location = New System.Drawing.Point(139, 63)
        Me.txt6ManagerUInput.Name = "txt6ManagerUInput"
        Me.txt6ManagerUInput.Size = New System.Drawing.Size(100, 20)
        Me.txt6ManagerUInput.TabIndex = 3
        '
        'txt6ManagerPInput
        '
        Me.txt6ManagerPInput.Location = New System.Drawing.Point(139, 123)
        Me.txt6ManagerPInput.Name = "txt6ManagerPInput"
        Me.txt6ManagerPInput.Size = New System.Drawing.Size(100, 20)
        Me.txt6ManagerPInput.TabIndex = 4
        '
        'frm6ManagerLogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.txt6ManagerPInput)
        Me.Controls.Add(Me.txt6ManagerUInput)
        Me.Controls.Add(Me.lbl6ManagerPassword)
        Me.Controls.Add(Me.lbl6ManagerUsername)
        Me.Name = "frm6ManagerLogin"
        Me.Text = "Manager"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl6ManagerUsername As Label
    Friend WithEvents lbl6ManagerPassword As Label
    Friend WithEvents txt6ManagerUInput As TextBox
    Friend WithEvents txt6ManagerPInput As TextBox
End Class
