﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm6EmployeeLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl6EmployeeUsername = New System.Windows.Forms.Label()
        Me.lbl6EmployeePassword = New System.Windows.Forms.Label()
        Me.txt6EmployeeUInput = New System.Windows.Forms.TextBox()
        Me.txt6EmployeePInput = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lbl6EmployeeUsername
        '
        Me.lbl6EmployeeUsername.AutoSize = True
        Me.lbl6EmployeeUsername.Location = New System.Drawing.Point(60, 61)
        Me.lbl6EmployeeUsername.Name = "lbl6EmployeeUsername"
        Me.lbl6EmployeeUsername.Size = New System.Drawing.Size(58, 13)
        Me.lbl6EmployeeUsername.TabIndex = 0
        Me.lbl6EmployeeUsername.Text = "Username:"
        '
        'lbl6EmployeePassword
        '
        Me.lbl6EmployeePassword.AutoSize = True
        Me.lbl6EmployeePassword.Location = New System.Drawing.Point(60, 113)
        Me.lbl6EmployeePassword.Name = "lbl6EmployeePassword"
        Me.lbl6EmployeePassword.Size = New System.Drawing.Size(56, 13)
        Me.lbl6EmployeePassword.TabIndex = 1
        Me.lbl6EmployeePassword.Text = "Password:"
        '
        'txt6EmployeeUInput
        '
        Me.txt6EmployeeUInput.Location = New System.Drawing.Point(135, 58)
        Me.txt6EmployeeUInput.Name = "txt6EmployeeUInput"
        Me.txt6EmployeeUInput.Size = New System.Drawing.Size(100, 20)
        Me.txt6EmployeeUInput.TabIndex = 2
        '
        'txt6EmployeePInput
        '
        Me.txt6EmployeePInput.Location = New System.Drawing.Point(135, 110)
        Me.txt6EmployeePInput.Name = "txt6EmployeePInput"
        Me.txt6EmployeePInput.Size = New System.Drawing.Size(100, 20)
        Me.txt6EmployeePInput.TabIndex = 3
        '
        'frm6EmployeeLogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.txt6EmployeePInput)
        Me.Controls.Add(Me.txt6EmployeeUInput)
        Me.Controls.Add(Me.lbl6EmployeePassword)
        Me.Controls.Add(Me.lbl6EmployeeUsername)
        Me.Name = "frm6EmployeeLogin"
        Me.Text = "Employee"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl6EmployeeUsername As Label
    Friend WithEvents lbl6EmployeePassword As Label
    Friend WithEvents txt6EmployeeUInput As TextBox
    Friend WithEvents txt6EmployeePInput As TextBox
End Class
