﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm6Welcome
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl6Company = New System.Windows.Forms.Label()
        Me.grp6ChooseLogin = New System.Windows.Forms.GroupBox()
        Me.btn6Employee = New System.Windows.Forms.Button()
        Me.btn6Manager = New System.Windows.Forms.Button()
        Me.grp6ChooseLogin.SuspendLayout()
        Me.SuspendLayout()
        '
        'lbl6Company
        '
        Me.lbl6Company.AutoSize = True
        Me.lbl6Company.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl6Company.Location = New System.Drawing.Point(121, 9)
        Me.lbl6Company.Name = "lbl6Company"
        Me.lbl6Company.Size = New System.Drawing.Size(234, 19)
        Me.lbl6Company.TabIndex = 0
        Me.lbl6Company.Text = "Dynamic Distribution Consultants"
        '
        'grp6ChooseLogin
        '
        Me.grp6ChooseLogin.Controls.Add(Me.btn6Manager)
        Me.grp6ChooseLogin.Controls.Add(Me.btn6Employee)
        Me.grp6ChooseLogin.Location = New System.Drawing.Point(90, 63)
        Me.grp6ChooseLogin.Name = "grp6ChooseLogin"
        Me.grp6ChooseLogin.Size = New System.Drawing.Size(300, 149)
        Me.grp6ChooseLogin.TabIndex = 3
        Me.grp6ChooseLogin.TabStop = False
        Me.grp6ChooseLogin.Text = "Choose Login"
        '
        'btn6Employee
        '
        Me.btn6Employee.Location = New System.Drawing.Point(83, 40)
        Me.btn6Employee.Name = "btn6Employee"
        Me.btn6Employee.Size = New System.Drawing.Size(135, 23)
        Me.btn6Employee.TabIndex = 0
        Me.btn6Employee.Text = "Employee"
        Me.btn6Employee.UseVisualStyleBackColor = True
        '
        'btn6Manager
        '
        Me.btn6Manager.Location = New System.Drawing.Point(83, 88)
        Me.btn6Manager.Name = "btn6Manager"
        Me.btn6Manager.Size = New System.Drawing.Size(135, 23)
        Me.btn6Manager.TabIndex = 1
        Me.btn6Manager.Text = "Manager"
        Me.btn6Manager.UseVisualStyleBackColor = True
        '
        'frm6Welcome
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(487, 427)
        Me.Controls.Add(Me.grp6ChooseLogin)
        Me.Controls.Add(Me.lbl6Company)
        Me.Name = "frm6Welcome"
        Me.Text = "Welcome"
        Me.grp6ChooseLogin.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl6Company As Label
    Friend WithEvents grp6ChooseLogin As GroupBox
    Friend WithEvents btn6Manager As Button
    Friend WithEvents btn6Employee As Button
End Class
