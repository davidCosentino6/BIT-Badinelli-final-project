﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.tblALOutput = New System.Windows.Forms.TableLayoutPanel()
        Me.tbxALJob1 = New System.Windows.Forms.TextBox()
        Me.tbxALJob2 = New System.Windows.Forms.TextBox()
        Me.tbxALJob3 = New System.Windows.Forms.TextBox()
        Me.cbxALJob1 = New System.Windows.Forms.CheckedListBox()
        Me.cbxALJob2 = New System.Windows.Forms.CheckedListBox()
        Me.cbxALJob3 = New System.Windows.Forms.CheckedListBox()
        Me.btnALCalcSchedule = New System.Windows.Forms.Button()
        Me.btnALDone = New System.Windows.Forms.Button()
        Me.tblALOutput.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(83, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Work Center #1 "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(83, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Work Center #2"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(3, 84)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(83, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Work Center #3"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(3, 112)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(83, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Work Center #4"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(92, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(36, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Job 1 "
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(181, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(33, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Job 2"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(270, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(36, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Job 3 "
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(359, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(63, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Total Loads"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(92, 123)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(69, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Assignments "
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(79, 60)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(102, 13)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Standard work load "
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(205, 27)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(36, 13)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Job 1 "
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(351, 27)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(36, 13)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "Job 2 "
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(486, 27)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(36, 13)
        Me.Label13.TabIndex = 12
        Me.Label13.Text = "Job 3 "
        '
        'tblALOutput
        '
        Me.tblALOutput.ColumnCount = 5
        Me.tblALOutput.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.tblALOutput.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.tblALOutput.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.tblALOutput.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.tblALOutput.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.tblALOutput.Controls.Add(Me.Label1, 0, 1)
        Me.tblALOutput.Controls.Add(Me.Label2, 0, 2)
        Me.tblALOutput.Controls.Add(Me.Label3, 0, 3)
        Me.tblALOutput.Controls.Add(Me.Label4, 0, 4)
        Me.tblALOutput.Controls.Add(Me.Label5, 1, 0)
        Me.tblALOutput.Controls.Add(Me.Label6, 2, 0)
        Me.tblALOutput.Controls.Add(Me.Label8, 4, 0)
        Me.tblALOutput.Controls.Add(Me.Label7, 3, 0)
        Me.tblALOutput.Location = New System.Drawing.Point(151, 251)
        Me.tblALOutput.Name = "tblALOutput"
        Me.tblALOutput.RowCount = 5
        Me.tblALOutput.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.tblALOutput.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.tblALOutput.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.tblALOutput.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.tblALOutput.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.tblALOutput.Size = New System.Drawing.Size(448, 142)
        Me.tblALOutput.TabIndex = 13
        '
        'tbxALJob1
        '
        Me.tbxALJob1.Location = New System.Drawing.Point(187, 53)
        Me.tbxALJob1.Name = "tbxALJob1"
        Me.tbxALJob1.Size = New System.Drawing.Size(83, 20)
        Me.tbxALJob1.TabIndex = 8
        '
        'tbxALJob2
        '
        Me.tbxALJob2.Location = New System.Drawing.Point(319, 53)
        Me.tbxALJob2.Name = "tbxALJob2"
        Me.tbxALJob2.Size = New System.Drawing.Size(100, 20)
        Me.tbxALJob2.TabIndex = 14
        '
        'tbxALJob3
        '
        Me.tbxALJob3.Location = New System.Drawing.Point(457, 53)
        Me.tbxALJob3.Name = "tbxALJob3"
        Me.tbxALJob3.Size = New System.Drawing.Size(100, 20)
        Me.tbxALJob3.TabIndex = 15
        '
        'cbxALJob1
        '
        Me.cbxALJob1.FormattingEnabled = True
        Me.cbxALJob1.Items.AddRange(New Object() {"Work Center #1", "Work Center #2", "Work Center #3", "Work Center #4"})
        Me.cbxALJob1.Location = New System.Drawing.Point(167, 92)
        Me.cbxALJob1.Name = "cbxALJob1"
        Me.cbxALJob1.Size = New System.Drawing.Size(120, 79)
        Me.cbxALJob1.TabIndex = 16
        '
        'cbxALJob2
        '
        Me.cbxALJob2.FormattingEnabled = True
        Me.cbxALJob2.Items.AddRange(New Object() {"Work Center #1", "Work Center #2", "Work Center #3", "Work Center #4"})
        Me.cbxALJob2.Location = New System.Drawing.Point(308, 92)
        Me.cbxALJob2.Name = "cbxALJob2"
        Me.cbxALJob2.Size = New System.Drawing.Size(120, 79)
        Me.cbxALJob2.TabIndex = 17
        '
        'cbxALJob3
        '
        Me.cbxALJob3.FormattingEnabled = True
        Me.cbxALJob3.Items.AddRange(New Object() {"Work Center #1", "Work Center #2", "Work Center #3", "Work Center #4"})
        Me.cbxALJob3.Location = New System.Drawing.Point(450, 92)
        Me.cbxALJob3.Name = "cbxALJob3"
        Me.cbxALJob3.Size = New System.Drawing.Size(120, 79)
        Me.cbxALJob3.TabIndex = 18
        '
        'btnALCalcSchedule
        '
        Me.btnALCalcSchedule.Location = New System.Drawing.Point(292, 210)
        Me.btnALCalcSchedule.Name = "btnALCalcSchedule"
        Me.btnALCalcSchedule.Size = New System.Drawing.Size(149, 23)
        Me.btnALCalcSchedule.TabIndex = 19
        Me.btnALCalcSchedule.Text = "Calculate Schedule "
        Me.btnALCalcSchedule.UseVisualStyleBackColor = True
        '
        'btnALDone
        '
        Me.btnALDone.Location = New System.Drawing.Point(335, 413)
        Me.btnALDone.Name = "btnALDone"
        Me.btnALDone.Size = New System.Drawing.Size(75, 23)
        Me.btnALDone.TabIndex = 20
        Me.btnALDone.Text = "Done "
        Me.btnALDone.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(772, 469)
        Me.Controls.Add(Me.btnALDone)
        Me.Controls.Add(Me.btnALCalcSchedule)
        Me.Controls.Add(Me.cbxALJob3)
        Me.Controls.Add(Me.cbxALJob2)
        Me.Controls.Add(Me.cbxALJob1)
        Me.Controls.Add(Me.tbxALJob3)
        Me.Controls.Add(Me.tbxALJob2)
        Me.Controls.Add(Me.tblALOutput)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.tbxALJob1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.tblALOutput.ResumeLayout(False)
        Me.tblALOutput.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents tblALOutput As TableLayoutPanel
    Friend WithEvents tbxALJob1 As TextBox
    Friend WithEvents tbxALJob2 As TextBox
    Friend WithEvents tbxALJob3 As TextBox
    Friend WithEvents cbxALJob1 As CheckedListBox
    Friend WithEvents cbxALJob2 As CheckedListBox
    Friend WithEvents cbxALJob3 As CheckedListBox
    Friend WithEvents btnALCalcSchedule As Button
    Friend WithEvents btnALDone As Button
End Class
