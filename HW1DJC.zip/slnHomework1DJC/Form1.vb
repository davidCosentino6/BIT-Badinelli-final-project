﻿Public Class frmDJCAutoApp
    'DJC: This part declares all of the constants that will be used throughout the program, and can be accessed within any subroutine
    Const BasePrice As Single = 25000
    Const PremiumSports As Single = 10000
    Const PremiumSUV As Single = 8000
    Const PremiumTruck As Single = 10000
    Const PremiumAutomatic As Single = 1000
    Const Premium5Speed As Single = 500
    Const Premium6Speed As Single = 800
    Const Premium7Speed As Single = 1200
    Const PremiumDiesel As Single = 500
    Const PremiumHybrid As Single = 2000
    Const PremiumElectric As Single = 3500

    'DJC: This declares the variables that will be used in the programs
    Dim budgetSurplus As Single = 0
    Dim userBudget As Single = 0
    Dim userCost As Single = 0

    '**********************************************************************************
    'DJC: This subroutine calculates the budget surplus/defecit and will produce a message regarding whether or not the user can afford the car
    Private Sub btnDJCCalculate_Click(sender As Object, e As EventArgs) Handles btnDJCCalculate.Click

        'DJC: This is setting the word chosen as a string, so it can be used if functions and select cases
        Dim chosen As String


        'DJC: This if statement will  act as an error trapping message, so if the user does not enter a budget they will be prompted to enter one in the rich text box
        If txtDJCBudget.Text.Equals("") Then
            rbxDJCResult.Text = ("Please enter your budget")
            Exit Sub
        Else userBudget = CInt(txtDJCBudget.Text)
        End If

        'DJC: This converts the user's budget entry into an integer and sets the budgetSurplus and userCost equal to 0
        userBudget = CInt(txtDJCBudget.Text)
        userCost = 0
        budgetSurplus = 0

        '*******************************************************************************
        'DJC: This select case will increase the userCost by the amount the vehicle type selected by the user costs
        chosen = cbxDJCAutoType.SelectedItem
        Select Case chosen
            Case "Sedan"
                userCost -= BasePrice
            Case "Sports Car"
                userCost = userCost - BasePrice - PremiumSports
            Case "SUV"
                userCost = userCost - BasePrice - PremiumSUV
            Case "Truck"
                userCost = userCost - BasePrice - PremiumTruck
        End Select
        '*******************************************************************************
        'DJC:These error trapping messages will ensure that the user enters a valid response to every question, and if one is not answered the message in the rich text box will prompt them to do so

        If cbxDJCAutoType.SelectedItem Is Nothing Then
            rbxDJCResult.Text = ("Please select a vehicle type")
            Exit Sub
        End If
        If cbxDJCEngine.SelectedItem Is Nothing Then
            rbxDJCResult.Text = ("Please select an engine")
            Exit Sub
        End If
        If lbxDJCTransmission.SelectedItem Is Nothing Then
            rbxDJCResult.Text = ("Please select a transmission")
            Exit Sub
        End If
        '**********************************************************************************
        'DJC: This if statement will increase the total user cost by the price of the engine selected
        chosen = cbxDJCEngine.SelectedItem
        If chosen = "Gasoline" Then userCost = userCost
        If chosen = "Diesel" Then userCost -= PremiumDiesel
        If chosen = "Hybrid" Then userCost -= PremiumHybrid
        If chosen = "Electric" Then
            userCost -= PremiumElectric
        End If
        '***********************************************************************************
        'DJC: This if statement will increase the total user cost by the price of the transmission selected
        chosen = lbxDJCTransmission.SelectedItem
        If chosen = "Automatic Transmission" Then userCost -= PremiumAutomatic
        If chosen = "Manual 5 Speed" Then userCost -= Premium5Speed
        If chosen = "Manual 6 Speed" Then userCost -= Premium6Speed
        If chosen = "Manual 7 Speed" Then
            userCost -= Premium7Speed
        End If
        '***************************************************************************************
        'DJC: This formula will calculate the budget surplus after the user has selected all of his/her premiums by subtracting the userCost from the userBudget
        budgetSurplus = userBudget - -userCost

        'DJC: This if statement will tell the user if they have a surplus or a defecit and if they can afford the car and by how much
        If 0 <= userBudget + userCost Then
            rbxDJCResult.Text = ("You can afford the car you have selected." & vbCrLf & "Your surplus is " + FormatCurrency(budgetSurplus, 2))

        End If
        If 0 >= userBudget + userCost Then
            rbxDJCResult.Text = ("We're sorry, but you cannot afford the car you have selected." & vbCrLf & "Your defecit is " + FormatCurrency(budgetSurplus, 2))
        End If



    End Sub
    'DJC: This private sub makes the done button exit out of the application when the user clicks on it
    Private Sub btnDJCDone_Click(sender As Object, e As EventArgs) Handles btnDJCDone.Click
        Me.Close()
    End Sub


End Class
