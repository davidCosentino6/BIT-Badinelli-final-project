﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDJCAutoApp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpDJCUserData = New System.Windows.Forms.GroupBox()
        Me.tblDJCUserPreferences = New System.Windows.Forms.TableLayoutPanel()
        Me.lbxDJCTransmission = New System.Windows.Forms.ListBox()
        Me.lblDJCEngine = New System.Windows.Forms.Label()
        Me.cbxDJCAutoType = New System.Windows.Forms.ComboBox()
        Me.cbxDJCEngine = New System.Windows.Forms.ComboBox()
        Me.lblDJCBudget = New System.Windows.Forms.Label()
        Me.lblDJCTransmission = New System.Windows.Forms.Label()
        Me.lblDJCAutoType = New System.Windows.Forms.Label()
        Me.txtDJCBudget = New System.Windows.Forms.TextBox()
        Me.lblDJCTitle = New System.Windows.Forms.Label()
        Me.lblDJCCanYouAffordIt = New System.Windows.Forms.Label()
        Me.rbxDJCResult = New System.Windows.Forms.RichTextBox()
        Me.btnDJCCalculate = New System.Windows.Forms.Button()
        Me.btnDJCDone = New System.Windows.Forms.Button()
        Me.grpDJCUserData.SuspendLayout()
        Me.tblDJCUserPreferences.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpDJCUserData
        '
        Me.grpDJCUserData.BackColor = System.Drawing.Color.Gainsboro
        Me.grpDJCUserData.Controls.Add(Me.tblDJCUserPreferences)
        Me.grpDJCUserData.Font = New System.Drawing.Font("Times New Roman", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpDJCUserData.Location = New System.Drawing.Point(107, 102)
        Me.grpDJCUserData.Name = "grpDJCUserData"
        Me.grpDJCUserData.Size = New System.Drawing.Size(855, 387)
        Me.grpDJCUserData.TabIndex = 0
        Me.grpDJCUserData.TabStop = False
        Me.grpDJCUserData.Text = "Data Entry"
        '
        'tblDJCUserPreferences
        '
        Me.tblDJCUserPreferences.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.tblDJCUserPreferences.ColumnCount = 2
        Me.tblDJCUserPreferences.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tblDJCUserPreferences.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tblDJCUserPreferences.Controls.Add(Me.lbxDJCTransmission, 1, 3)
        Me.tblDJCUserPreferences.Controls.Add(Me.lblDJCEngine, 0, 2)
        Me.tblDJCUserPreferences.Controls.Add(Me.cbxDJCAutoType, 1, 1)
        Me.tblDJCUserPreferences.Controls.Add(Me.cbxDJCEngine, 1, 2)
        Me.tblDJCUserPreferences.Controls.Add(Me.lblDJCBudget, 0, 0)
        Me.tblDJCUserPreferences.Controls.Add(Me.lblDJCTransmission, 0, 3)
        Me.tblDJCUserPreferences.Controls.Add(Me.lblDJCAutoType, 0, 1)
        Me.tblDJCUserPreferences.Controls.Add(Me.txtDJCBudget, 1, 0)
        Me.tblDJCUserPreferences.Location = New System.Drawing.Point(6, 47)
        Me.tblDJCUserPreferences.Name = "tblDJCUserPreferences"
        Me.tblDJCUserPreferences.RowCount = 4
        Me.tblDJCUserPreferences.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.tblDJCUserPreferences.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.tblDJCUserPreferences.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.tblDJCUserPreferences.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.tblDJCUserPreferences.Size = New System.Drawing.Size(1030, 318)
        Me.tblDJCUserPreferences.TabIndex = 8
        '
        'lbxDJCTransmission
        '
        Me.lbxDJCTransmission.Font = New System.Drawing.Font("Times New Roman", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbxDJCTransmission.FormattingEnabled = True
        Me.lbxDJCTransmission.ItemHeight = 31
        Me.lbxDJCTransmission.Items.AddRange(New Object() {"Automatic Transmission", "Manual 5 Speed", "Manual 6 Speed", "Manual 7 Speed"})
        Me.lbxDJCTransmission.Location = New System.Drawing.Point(518, 186)
        Me.lbxDJCTransmission.Name = "lbxDJCTransmission"
        Me.lbxDJCTransmission.Size = New System.Drawing.Size(282, 128)
        Me.lbxDJCTransmission.TabIndex = 3
        '
        'lblDJCEngine
        '
        Me.lblDJCEngine.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lblDJCEngine.AutoSize = True
        Me.lblDJCEngine.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblDJCEngine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDJCEngine.Font = New System.Drawing.Font("Times New Roman", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDJCEngine.Location = New System.Drawing.Point(109, 135)
        Me.lblDJCEngine.Name = "lblDJCEngine"
        Me.lblDJCEngine.Size = New System.Drawing.Size(403, 35)
        Me.lblDJCEngine.TabIndex = 4
        Me.lblDJCEngine.Text = "What kind of engine do you want?"
        '
        'cbxDJCAutoType
        '
        Me.cbxDJCAutoType.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cbxDJCAutoType.Font = New System.Drawing.Font("Times New Roman", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxDJCAutoType.FormattingEnabled = True
        Me.cbxDJCAutoType.Items.AddRange(New Object() {"Sedan", "Sports Car", "SUV", "Truck"})
        Me.cbxDJCAutoType.Location = New System.Drawing.Point(518, 72)
        Me.cbxDJCAutoType.Name = "cbxDJCAutoType"
        Me.cbxDJCAutoType.Size = New System.Drawing.Size(282, 39)
        Me.cbxDJCAutoType.TabIndex = 1
        '
        'cbxDJCEngine
        '
        Me.cbxDJCEngine.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cbxDJCEngine.Font = New System.Drawing.Font("Times New Roman", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxDJCEngine.FormattingEnabled = True
        Me.cbxDJCEngine.Items.AddRange(New Object() {"Gasoline", "Diesel", "Hybrid", "Electric"})
        Me.cbxDJCEngine.Location = New System.Drawing.Point(518, 133)
        Me.cbxDJCEngine.Name = "cbxDJCEngine"
        Me.cbxDJCEngine.Size = New System.Drawing.Size(282, 39)
        Me.cbxDJCEngine.TabIndex = 2
        '
        'lblDJCBudget
        '
        Me.lblDJCBudget.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lblDJCBudget.AutoSize = True
        Me.lblDJCBudget.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblDJCBudget.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDJCBudget.Font = New System.Drawing.Font("Times New Roman", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDJCBudget.Location = New System.Drawing.Point(227, 14)
        Me.lblDJCBudget.Name = "lblDJCBudget"
        Me.lblDJCBudget.Size = New System.Drawing.Size(285, 33)
        Me.lblDJCBudget.TabIndex = 2
        Me.lblDJCBudget.Text = "Please enter your budget"
        '
        'lblDJCTransmission
        '
        Me.lblDJCTransmission.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblDJCTransmission.AutoSize = True
        Me.lblDJCTransmission.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblDJCTransmission.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDJCTransmission.Font = New System.Drawing.Font("Times New Roman", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDJCTransmission.Location = New System.Drawing.Point(7, 183)
        Me.lblDJCTransmission.Name = "lblDJCTransmission"
        Me.lblDJCTransmission.Size = New System.Drawing.Size(505, 33)
        Me.lblDJCTransmission.TabIndex = 5
        Me.lblDJCTransmission.Text = "What transmission do you want? - check one"
        '
        'lblDJCAutoType
        '
        Me.lblDJCAutoType.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lblDJCAutoType.AutoSize = True
        Me.lblDJCAutoType.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblDJCAutoType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDJCAutoType.Font = New System.Drawing.Font("Times New Roman", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDJCAutoType.Location = New System.Drawing.Point(104, 74)
        Me.lblDJCAutoType.Name = "lblDJCAutoType"
        Me.lblDJCAutoType.Size = New System.Drawing.Size(408, 35)
        Me.lblDJCAutoType.TabIndex = 3
        Me.lblDJCAutoType.Text = "What type of vehicle do you want?"
        '
        'txtDJCBudget
        '
        Me.txtDJCBudget.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtDJCBudget.Font = New System.Drawing.Font("Times New Roman", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDJCBudget.Location = New System.Drawing.Point(518, 11)
        Me.txtDJCBudget.Name = "txtDJCBudget"
        Me.txtDJCBudget.Size = New System.Drawing.Size(169, 39)
        Me.txtDJCBudget.TabIndex = 0
        '
        'lblDJCTitle
        '
        Me.lblDJCTitle.AutoSize = True
        Me.lblDJCTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblDJCTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDJCTitle.Font = New System.Drawing.Font("Times New Roman", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDJCTitle.Location = New System.Drawing.Point(653, 26)
        Me.lblDJCTitle.Name = "lblDJCTitle"
        Me.lblDJCTitle.Size = New System.Drawing.Size(156, 33)
        Me.lblDJCTitle.TabIndex = 1
        Me.lblDJCTitle.Text = "Auto Picker"
        '
        'lblDJCCanYouAffordIt
        '
        Me.lblDJCCanYouAffordIt.AutoSize = True
        Me.lblDJCCanYouAffordIt.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblDJCCanYouAffordIt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDJCCanYouAffordIt.Font = New System.Drawing.Font("Times New Roman", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDJCCanYouAffordIt.Location = New System.Drawing.Point(1092, 204)
        Me.lblDJCCanYouAffordIt.Name = "lblDJCCanYouAffordIt"
        Me.lblDJCCanYouAffordIt.Size = New System.Drawing.Size(214, 33)
        Me.lblDJCCanYouAffordIt.TabIndex = 6
        Me.lblDJCCanYouAffordIt.Text = "Can you afford it?"
        '
        'rbxDJCResult
        '
        Me.rbxDJCResult.Location = New System.Drawing.Point(1092, 270)
        Me.rbxDJCResult.Name = "rbxDJCResult"
        Me.rbxDJCResult.Size = New System.Drawing.Size(286, 154)
        Me.rbxDJCResult.TabIndex = 9
        Me.rbxDJCResult.Text = ""
        '
        'btnDJCCalculate
        '
        Me.btnDJCCalculate.Font = New System.Drawing.Font("Times New Roman", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDJCCalculate.Location = New System.Drawing.Point(1092, 102)
        Me.btnDJCCalculate.Name = "btnDJCCalculate"
        Me.btnDJCCalculate.Size = New System.Drawing.Size(192, 41)
        Me.btnDJCCalculate.TabIndex = 4
        Me.btnDJCCalculate.Text = "Calculate"
        Me.btnDJCCalculate.UseVisualStyleBackColor = True
        '
        'btnDJCDone
        '
        Me.btnDJCDone.Font = New System.Drawing.Font("Times New Roman", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDJCDone.Location = New System.Drawing.Point(1092, 447)
        Me.btnDJCDone.Name = "btnDJCDone"
        Me.btnDJCDone.Size = New System.Drawing.Size(192, 42)
        Me.btnDJCDone.TabIndex = 5
        Me.btnDJCDone.Text = "Done"
        Me.btnDJCDone.UseVisualStyleBackColor = True
        '
        'frmDJCAutoApp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Navy
        Me.ClientSize = New System.Drawing.Size(1488, 544)
        Me.Controls.Add(Me.btnDJCDone)
        Me.Controls.Add(Me.btnDJCCalculate)
        Me.Controls.Add(Me.rbxDJCResult)
        Me.Controls.Add(Me.lblDJCCanYouAffordIt)
        Me.Controls.Add(Me.lblDJCTitle)
        Me.Controls.Add(Me.grpDJCUserData)
        Me.Name = "frmDJCAutoApp"
        Me.Text = "Auto App"
        Me.grpDJCUserData.ResumeLayout(False)
        Me.tblDJCUserPreferences.ResumeLayout(False)
        Me.tblDJCUserPreferences.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grpDJCUserData As GroupBox
    Friend WithEvents lblDJCTitle As Label
    Friend WithEvents lblDJCBudget As Label
    Friend WithEvents lblDJCAutoType As Label
    Friend WithEvents lblDJCEngine As Label
    Friend WithEvents lblDJCTransmission As Label
    Friend WithEvents lblDJCCanYouAffordIt As Label
    Friend WithEvents txtDJCBudget As TextBox
    Friend WithEvents tblDJCUserPreferences As TableLayoutPanel
    Friend WithEvents cbxDJCAutoType As ComboBox
    Friend WithEvents cbxDJCEngine As ComboBox
    Friend WithEvents lbxDJCTransmission As ListBox
    Friend WithEvents rbxDJCResult As RichTextBox
    Friend WithEvents btnDJCCalculate As Button
    Friend WithEvents btnDJCDone As Button
End Class
